# React + Vite

e-book 도서 대여 및 구매 시스템 사이트 프로젝트 입니다.

**진행부분**
- react + vite + RestApi
- 모바일, 태블릿, PC 적응형(반응형) style
- 메인페이지, UI 컴포넌트 구조
- Gnb 메뉴, 링크 컴포넌트, footer 컴포넌트
- 카드타입1 - 검색 ui , 베스트도서
- 카드타입2 - 결재방법
- 카드타입3 - 대여목록 대시보드 - 컬럼 클릭시 sort : Asc, Desc,
- 메뉴 스크롤 Section 활성화, 클릭시 이동 UI
- module-css , styled-components, assets(image, js, css) 구조

**진행예정**
- 회원가입 : 폼 컴포넌트, 가입
- 로그인 : 정상로그인, 에러
- 도서 목록 - 상세페이지
- 장바구니
- 로딩, 로그인 전역관리

# Tech
React, Router, style-components, 
props, state, 이벤트연결, 리스트 랜더링, 컴포넌트 구조
